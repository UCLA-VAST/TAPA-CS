#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef float data_t;
#define N 16
